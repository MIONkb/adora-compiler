#!/bin/bash

rootfolder=$(pwd)
IRfolder="IR"
srcfolder="$rootfolder/$IRfolder/3_cgra_exes"
asmfolder="$rootfolder/$IRfolder/4_asms"
tarfolder="$rootfolder/$IRfolder/5_obj"
tempfolder="$rootfolder/$IRfolder/tempfiles"
func_name="forward"
main_file="main.c"
baremetal_file_name="bert-linux"

if [ ! -d "$tarfolder" ]; then
  mkdir -p "$tarfolder"
  echo mkdir -p "$tarfolder"
fi
if [ ! -d "$tempfolder" ]; then
  mkdir -p "$tempfolder"
  echo mkdir -p "$tempfolder"
fi

asm_files=$(find "$asmfolder" -name "*.s" -type f)
src_files=$(find "$srcfolder" -name "*.c" -type f)

# echo $asm_files
# echo $src_files
set -x

source $CHIPYARD_SOURCE_ENV
conda activate $CHIPYARD_DIR/.conda-env

# echo \
# riscv64-unknown-linux-gnu-gcc \
#  -DPREALLOCATE=1 -DMULTITHREAD=1 -mcmodel=medany \
#   -O2 -ffast-math -fno-common -fno-builtin-printf \
#  -fno-tree-loop-distribute-patterns -march=rv64gc -Wa,-march=rv64gc12 \
#   -lm -lgcc \
#  -I/home/jhlou/chipyard/generators/fdra/software/tests//riscv-tests/benchmarks/common \
#  -I/home/jhlou/chipyard/generators/fdra/software/tests/riscv-tests \
#  -I/home/jhlou/chipyard/generators/fdra/software/tests//riscv-tests/env \
#  -I/home/jhlou/chipyard/generators/fdra/software/tests/ \
#  -DID_STRING=  -static  \
#  -g \
#  -o $tarfolder/$baremetal_file_name \
#  $rootfolder/$main_file \
#  $asm_files \
#  $src_files \
#  $CHIPYARD_DIR/generators/fdra/software/tests/UtilSrc/syscalls.c  \
#  $CHIPYARD_DIR/.conda-env/riscv-tools/riscv64-unknown-elf/lib/libm.a

riscv64-unknown-linux-gnu-gcc \
 -DPREALLOCATE=1 -DMULTITHREAD=1 -mcmodel=medany \
  -O2 -ffast-math -fno-common -fno-builtin-printf -fno-math-errno \
 -fno-tree-loop-distribute-patterns -march=rv64gc -Wa,-march=rv64gc12 \
 -lc -lm -lgcc -lc \
  -L /home/jhlou/chipyard/.conda-env/riscv-tools/sysroot/lib \
  -L /home/jhlou/chipyard/.conda-env/riscv-tools/riscv64-unknown-linux-gnu/lib \
 -I/home/jhlou/chipyard/generators/fdra/software/tests//riscv-tests/benchmarks/common \
 -I/home/jhlou/chipyard/generators/fdra/software/tests/riscv-tests \
 -I/home/jhlou/chipyard/generators/fdra/software/tests//riscv-tests/env \
 -I/home/jhlou/chipyard/generators/fdra/software/tests/ \
 -DID_STRING=  -static  \
 -g \
 -o $tarfolder/$baremetal_file_name \
 $rootfolder/$main_file \
 $asm_files \
 $src_files \
 -lm

#  $CHIPYARD_DIR/.conda-env/riscv-tools/riscv64-unknown-elf/lib/libm.a \

#  /home/jhlou/chipyard/.conda-env/riscv-tools/sysroot/lib/libm.so.6 \
#  /home/jhlou/chipyard/.conda-env/riscv-tools/sysroot/lib/libgcc_s.so
#  $CHIPYARD_DIR/.conda-env/riscv-tools/riscv64-unknown-elf/lib/libm.a 
 
  # \\
#  $CHIPYARD_DIR/.conda-env/riscv-tools/riscv64-unknown-elf/lib/libm.a 

#  $CHIPYARD_DIR/.conda-env/riscv-tools/riscv64-unknown-linux-gnu/lib/libstdc++.a
 #  -L/home/jhlou/chipyard/.conda-env/riscv-tools/riscv64-unknown-elf/lib/ \
#  $CHIPYARD_DIR/generators/fdra/software/tests/UtilSrc/syscalls.c  \
#  $CHIPYARD_DIR/generators/fdra/software/tests/UtilSrc/CRunnerUtils.cpp \

set +x